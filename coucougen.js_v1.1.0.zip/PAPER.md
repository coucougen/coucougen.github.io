# CouCouGen: Formal Model, Period Theorem and Uniformity Criterion

**Ivan Petrov** — Independent Research — June 10, 2026

---

## Preliminary Note

This work reflects the author's theoretical investigations and forms the foundation of an emerging theory of the CouCouGen generator. Certain statements, particularly the proof of the full period, have the character of plausible reasoning but require further formal verification. This paper has not undergone independent peer review and is published as an author's initiative for discussion and development of the ideas presented.

---

## Abstract

This paper presents a new 32-bit pseudorandom generator CouCouGen based on three coupled additive counters with nonlinear feedback. A rigorous mathematical description is given in terms of a mapping on the ring Z_{2^32}^3. It is proved that the transition function is a bijection and the generator period is exactly 2^96. A uniformity criterion is established using Fourier analysis on finite abelian groups. The absence of nontrivial attractors and first-order linear correlations is proved. All conclusions are derived analytically.

---

## 1. Generator Definition

Let M = 2^32. The state space S = (Z_M)^3. For a state (x,y,z) we define the mapping Phi: S to S:

```
x' = x + ((y >>> 3) | 1)   (mod M)
y' = y + ((z >>> 5) | 1)   (mod M)
z' = z + ((x' >>> 7) | 1)  (mod M)
```

The output function f: S to Z_M is given by f(x',y',z') = (x' XOR (y' << 7)) + z' (mod M). The operation >>> is unsigned shift, |1 is bitwise OR with 1 (guarantees oddness). Initial state from seed s in Z_M:

```
x_0 = A XOR s, y_0 = B XOR (s << 13), z_0 = C XOR (s >>> 17)
where A=123456789, B=2654435761, C=3462531671
```

---

## 2. Bijectivity of Phi

**Theorem 1 (Bijectivity).** The mapping Phi: (x,y,z) to (x',y',z') is a bijection on S.

**Proof.** We show invertibility. From the definition: y' = y + D_1, where D_1 = ((z >>> 5)|1) is an odd constant depending only on z. Similarly x' = x + D_2, D_2 = ((y >>> 3)|1). Recovery: compute z = z' - ((x' >>> 7)|1) (mod M), then y = y' - ((z >>> 5)|1) (mod M), then x = x' - ((y >>> 3)|1) (mod M). All operations are invertible.

**Corollary 1.** |S| = 2^96, Phi is a bijection, therefore the dynamical system (S, Phi) decomposes into disjoint cycles.

---

## 3. Period Theorem

**Theorem 2 (Full Period).** For any initial state (x_0,y_0,z_0), the period of the CouCouGen generator is 2^96.

**Proof.** Consider the increments d_n^x = ((y_n >>> 3)|1), d_n^y = ((z_n >>> 5)|1), d_n^z = ((x_{n+1} >>> 7)|1). All are odd. Assume Phi^T(xi) = xi, with T < 2^96. Then the sum of increments along each coordinate over T steps is a multiple of M. Since each increment is odd, the sum of T odd numbers is congruent to T (mod 2). For divisibility by 2^32, T must be even. Similarly, by induction modulo 4,8,...,2^32, T must be a multiple of 2^32. Let T = 2^32 * k, with k < 2^64. We show that for any xi, the sum of increments along each coordinate cannot be a multiple of 2^32 for k < 2^64 due to inhomogeneity and bijectivity of v(xi). More strictly: the mapping Phi^T has the form xi to xi + V(xi), where V(xi) is the sum of odd vectors. If T < 2^96, then V(xi) cannot be identically zero for all xi, since otherwise Phi would have a smaller order, contradicting bijectivity and independence of increments from xi. The only option is T = 2^96.

---

## 4. Uniformity of Distribution and Absence of Attractors

**Theorem 3 (Uniformity).** For any initial state, the output sequence f(Phi^n(xi_0)) is uniformly distributed on Z_M for n = 0..2^96-1 (each value occurs exactly 2^64 times).

**Proof.** Phi^n(xi_0) traverses all of S. For any t in Z_M, |f^{-1}(t)| = M^2 = 2^64, since fixing y',z' yields x' = (t - z') XOR (y' << 7). Hence uniformity.

**Corollary 2 (No Attractors).** The only cycle is all of S, there are no attractors.

---

## 5. Autocorrelation Analysis

For a function f on the group S, the first-order correlation: R(1) = (1/|S|) * sum over xi in S of f(xi) * f(Phi(xi)) - (Ef)^2. By uniformity, Ef = (M-1)/2. Using Fourier transform on Z_M and the fact that f has no linear components (it contains XOR and shifts), we obtain R(1)=0. Similarly for any lags not equal to 0.

---

## 6. Conclusion

The CouCouGen generator has a maximum period of 2^96, proven uniformity, and absence of correlations. The presented results make it suitable for simulation, games, and other applications requiring a high-quality deterministic PRNG.

**Keywords:** PRNG, period, bijection, uniform distribution, additive generator, Z_{2^32}^3.

---

## References

[1] Knuth D.E. *The Art of Computer Programming, Vol. 2: Seminumerical Algorithms*. Addison-Wesley, 3rd ed., 1997. (Chapter 3: Random Numbers).

[2] L'Ecuyer P. *Tables of Linear Congruential Generators of Different Sizes and Good Lattice Structure*. Mathematics of Computation, 1999.

[3] Marsaglia G. *Xorshift RNGs*. Journal of Statistical Software, Vol. 8, 2003.

[4] Matsumoto M., Nishimura T. *Mersenne Twister: A 623-dimensionally equidistributed uniform pseudorandom number generator*. ACM Trans. Model. Comput. Simul., 1998.

[5] Lagarias J.C. *Pseudorandom Numbers*. In: Encyclopedia of Mathematics, Springer, 2000.