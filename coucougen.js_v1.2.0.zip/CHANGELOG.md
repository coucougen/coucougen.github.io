# Changelog

All notable changes to CouCouGen will be documented in this file.

## [1.2.0] - 2026-06-14

### Changed
- Repositioned library: no longer claims to be a PRNG
- Description changed to "deterministic sequence generator based on three interacting counters"
- Added explicit Known Limitations section with Dieharder test results
- Clarified that the generator fails bit-level tests (rank_32x32, bitstream, count_1s, etc.)
- Documented that LSBs flip deterministically due to odd increments
- Updated documentation to set realistic expectations
- No code changes from v1.1.0 — only documentation and positioning

### Added
- Dieharder test results table with p-values
- Practical use cases table (Good / Caution / Avoid / Never)
- Open research questions section (parallel coupling, shift tuning, stronger mixers, etc.)
- Bilingual paper (PAPER.md) with mathematical analysis
- CC BY-NC 4.0 license for documentation and paper

### Removed
- All claims of "pseudorandom number generator"
- Claim of parity with Math.random() quality (was based on insufficient testing)

## [1.1.0] - 2026-06-10

### Added
- PCG-like multiplication mixer for output: (t * 1103515245 + 12345)
- Full documentation in English and Russian
- README.md, README-ru.md, CHANGELOG.md
- package.json for npm publishing
- Usage examples for browser and Node.js

### Changed
- Output function extended with multiplication step for better statistical properties
- Autocorrelation reduced by 30x (from 0.062 to 0.002)

### Fixed
- None (first improvement release)

## [1.0.0] - 2026-06-02

### Added
- Initial public release
- Core algorithm: three coupled 32-bit counters with odd increments
- Basic XOR+ADD output function: (a ^ (b << 7)) + c
- Seed support with three initialization constants
- Cross-platform support: browser (global), Node.js (require), ES Modules, AMD
- Initial constants: 123456789, 2654435761 (2^32 / phi), 3462531671 (2^32 / sqrt(2))
- License: MIT